package com.maersk.containerbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContainerBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
