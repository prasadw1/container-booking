package com.maersk.containerbooking.model;

public class ContainerAvailRes {

	String available;

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
	}
}
