package com.maersk.containerbooking.model;

public enum ContainerType {
	DRY, REEFER
}
