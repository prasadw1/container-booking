package com.maersk.containerbooking.repositiry;

//@Repository
/*public interface BookingRepo extends Repository<Bookings, UUID> {

}
*/