package com.maersk.containerbooking.controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.maersk.containerbooking.model.Bookings;
import com.maersk.containerbooking.model.ContainerAvailReq;
import com.maersk.containerbooking.model.ContainerAvailRes;
//import com.maersk.containerbooking.repositiry.BookingRepo;

import reactor.core.publisher.Mono;

@RestController
public class BookingController {
	//@Autowired
	//BookingRepo bookingRepo;
	
	@GetMapping("/api/bookings")
	private Mono<ContainerAvailRes> checkAvailability() {
		ContainerAvailRes containerAvailRes = new ContainerAvailRes();
		//RestTemplate apiCall= new RestTemplate();
		//String res = apiCall.postForObject("https://www.maersk.com/api/bookings/checkAvailable", ontainerAvailReq, String.class);
		int availSize = 6;
		if(availSize > 0) {
			containerAvailRes.setAvailable("true");
		}else {
			containerAvailRes.setAvailable("false");
		}
	    return Mono.just(containerAvailRes);
	}
	@PostMapping("/api/bookings")
	private Mono<Bookings> bookingContainer(@RequestBody ContainerAvailReq containerAvailReq) {
		Bookings  booking = new Bookings();
		
		//Did not worked on cassandra so not implemented this
		/*booking.setContainerSize(containerAvailReq.getContainerSize());
		booking.setContainerType(containerAvailReq.getContainerType());
		booking.setDestination(containerAvailReq.getDestination());
		booking.setOrigin(containerAvailReq.getOrigin());
		booking.setQuantity(containerAvailReq.getQuantity());
		bookingRepo.save(booking);*/
		booking.setBookingRef("adfdaffa");
		return Mono.just(booking);
	}
}
